# -*- coding: utf-8 -*-
from xbmcswift2 import Plugin, xbmc, xbmcgui, xbmcplugin
from api import API
from config import config


plugin = Plugin()
api = API(plugin)


@plugin.route('/')
def index():
    content_type = plugin.request.args['content_type'][0] if 'content_type' in plugin.request.args else 'audio'
    return plugin.finish([{
        'label': item['channelName'],
        'icon': '{0}/img/channels/{1}.png'.format(config['urls']['website'], item['site_code']),
        'path': plugin.url_for('show_channel', channel_code=item['channel_code'], content_type=content_type),
        'properties': {
            'fanart_image': plugin.addon.getAddonInfo('fanart')
        }
    } for item in api.get_all_live()['liveBroadcasts']
                          if (content_type == 'video' and
                            item['channel_code'] in config['tv_channels']) or
                          (content_type == 'audio' and
                            item['channel_code'] not in config['tv_channels'])])


@plugin.route('/channel/<channel_code>')
def show_channel(channel_code):
    channel_name = [item for item in api.get_all_live()['liveBroadcasts'] if item['channel_code'] == channel_code][0]['channelName']
    # Playing now:
    items = [{
        'label': u'[B]{0}{1}: {2}[/B]'.format(plugin.get_string(30010), channel_name, item['title']),
        'icon': item['defaultThumbnailUrl'].strip(),
        'path': api.get_live_streaming_url(item['source_url']),
        'is_playable': True,
        'info_type': 'video' if plugin.request.args['content_type'][0] == 'video' else 'music',
        'info': {
            'Title': u'{0}: {1}'.format(channel_name, item['title'])
        },
        'properties': {
            'fanart_image': item['defaultThumbnailUrl'].strip()
        }
    } for item in api.get_channel_live(channel_code)]
    # Static items: Schedule & VOD:
    items = items + [
        {
            'label': u'{0} {1}'.format(plugin.get_string(30011), channel_name),  # Schedule
            'icon': 'special://home/addons/plugin.audio.iba-vod/resources/media/schedule.jpg',
            'path': plugin.url_for('show_channel_schedule', channel_code=channel_code, content_type=plugin.request.args['content_type'][0]),
            'properties': {
                'fanart_image': 'special://home/addons/plugin.audio.iba-vod/resources/media/schedule.jpg'
            }
        },
        {
            'label': u'{0} {1}'.format(plugin.get_string(30012), channel_name),  # VOD
            'icon': 'special://home/addons/plugin.audio.iba-vod/resources/media/vod.jpg',
            'path': plugin.url_for('show_channel_vod', channel_code=channel_code, content_type=plugin.request.args['content_type'][0]),
            'properties': {
                'fanart_image': 'special://home/addons/plugin.audio.iba-vod/resources/media/vod.jpg'
            }
        }
    ]
    return plugin.finish(items)


@plugin.route('/channel/<channel_code>/schedule')
def show_channel_schedule(channel_code):
    # plugin.set_content('episodes')
    return plugin.finish([{
        'label': u'{0} - {1} ({2})'.format(item['frmttd_time'], item['title'], item['janar_desc']),
        'icon': '{0}/pictures/p{1}.{2}'.format(config['urls']['website'], item['media_code'], item['file_extension']),
        'path': 'AlarmClock()',
        'properties': {
            'fanart_image': '{0}/pictures/p{1}.{2}'.format(config['urls']['website'], item['media_code'], item['file_extension'])
        }
    } for item in api.get_channel_schedule(channel_code)['schedule']])


@plugin.route('/channel/<channel_code>/vod')
def show_channel_vod(channel_code):
    return plugin.finish([{
        'label': u'{0} - {1}'.format(item['title'], item['media_desc']),
        'icon': '{0}/pictures/p{1}.{2}'.format(config['urls']['website'], item['media_code'], item['file_extension']),
        'path': plugin.url_for('show_program_vod', channel_code=channel_code,
                               schedule_code=item['schedule_code'],
                               date=item['formatted_start_time'][0:item['formatted_start_time'].find(' ')],
                               icon='{0}/pictures/p{1}.{2}'.format(config['urls']['website'], item['media_code'], item['file_extension']),
                               content_type=plugin.request.args['content_type'][0]),
        'properties': {
            'fanart_image': '{0}/pictures/p{1}.{2}'.format(config['urls']['website'], item['media_code'], item['file_extension'])
        }
    } for item in api.get_channel_vod(channel_code)['schedules']])


@plugin.route('/channel/<channel_code>/program/<schedule_code>/vod')
def show_program_vod(channel_code, schedule_code):
    return plugin.finish([{
        'label': u'{0} {1}'.format(plugin.get_string(30013), item['date']),
        'icon': plugin.request.args['icon'][0],
        'path': plugin.url_for('play_vod', channel_code=channel_code,
                               schedule_code=item['schedule_code'],
                               content_type=plugin.request.args['content_type'][0]),
        'properties': {
            'fanart_image': plugin.request.args['icon'][0]
        }
    } for item in api.get_program_vod(plugin.request.args['date'][0], schedule_code)])


@plugin.route('/channel/<channel_code>/play/<schedule_code>')
def play_vod(channel_code, schedule_code):
    media = api.get_vod_streaming(schedule_code)
    channel_name = [item for item in api.get_all_live()['liveBroadcasts'] if item['channel_code'] == channel_code][0]['channelName']
    listitem = xbmcgui.ListItem(media.title.get_text(), iconImage=media.posterlinks.posterimg.get_text())
    listitem.setArt({
        'poster': media.posterlinks.posterimg.get_text(),
        'fanart' : media.posterlinks.posterimg.get_text()
    })
    listitem.setInfo('video' if plugin.request.args['content_type'][0] == 'video' else 'music', {
        'Title': u'{0} VOD: {1}'.format(channel_name, media.title.get_text())
    })
    listitem.setProperty('IsPlayable', 'true')
    listitem.setProperty('Artist_Description', media.description.get_text())
    xbmc.Player().play(media.playbacklinks.find_all('fileurl')[-1].get_text(), listitem)


if __name__ == '__main__':
    plugin.run()
