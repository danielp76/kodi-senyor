config = {
    'urls': {
        'website': 'http://www.iba.org.il',
        'api': 'http://www.iba.org.il/webWCF/web.svc/',
        'live': 'http://www.iba.org.il/webWCF/web.svc/getdata?d=eyJzcCI6Ik1DX2xpdmUiLCJ1c2VDYWNoZSI6IjAiLCJhcnJQYXJhbXMiOltdfQ==',
        'program_vod': '/program.aspx?scode={0}',
        'schedule': 'http://www.iba.org.il/webWCF/web.svc/GetDataCache?d={0}',
        'schedule_qs': '{{"sp":"schedule_select","arrParams":[["fromdate","{0}"],["todate","{1}"],["channel_code",{2}],["use_alt",0]]}}',
        'channel_schedule_qs': '{{"sp":"MC_schedules_select","arrParams":[["channel",{0}]]}}',
        'live_streaming': 'http://iba-metadata-rr-d.vidnt.com/radio/iba/{0}/hls/metadata.xml?smil_profile=default',
        'vod_streaming': 'http://iba-metadata-rr-d.vidnt.com/vod/vod/{0}/hls/metadata.xml?smil_profile=default'
    },
    'tv_channels': ['1','7']
}