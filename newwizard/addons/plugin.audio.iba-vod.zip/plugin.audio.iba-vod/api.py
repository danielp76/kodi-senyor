# -*- coding: utf-8 -*-
import base64
from datetime import datetime, timedelta
import requests
import json
from config import config
from bs4 import BeautifulSoup


class API:
    def __init__(self, plugin):
        self.plugin = plugin

    def get_all_live(self):
        """
        Returns all live channels
        :return: Channel dictionary array
        """
        r = requests.get(config['urls']['live'])
        if r.status_code == 200:
            return json.loads(base64.b64decode(r.content))
        return []

    def get_channel_live(self, channel_code):
        """
        Returns a channel from live channels
        :param channel_code: channel code
        :return: channel dictionary
        """
        return [i for i in (self.get_all_live())['liveBroadcasts'] if channel_code == i['channel_code']]

    def get_channel_schedule(self, channel_code):
        r = requests.get(config['urls']['schedule'].format(base64.b64encode(config['urls']['schedule_qs'].format(
            (datetime.now() - timedelta(hours=1)).strftime('%Y-%m-%d %H:%M'),
            (datetime.now() + timedelta(hours=12)).strftime('%Y-%m-%d %H:%M'),
            channel_code
        ))))
        if r.status_code == 200:
            return json.loads(base64.b64decode(r.content[1:-1]))
        return []

    def get_channel_vod(self, channel_code):
        r = requests.get(config['urls']['schedule'].format(base64.b64encode(config['urls']['channel_schedule_qs'].
            format(channel_code))))
        if r.status_code == 200:
            return json.loads(base64.b64decode(r.content[1:-1]))
        return []

    def get_program_vod(self, date, schedule_code):
        items = []
        r = requests.get('{0}{1}'.format(config['urls']['website'], config['urls']['program_vod'].format(schedule_code)))
        if r.status_code == 200:
            soup = BeautifulSoup(r.content, 'html5lib')
            items.append({
                'date': date.replace('/', '.'),
                'schedule_code': schedule_code
            })
            items += [{
                'date': item.get_text(),
                'schedule_code': item.get('href')[item.get('href').find('=') + 1:]
            } for item in soup.select('.rowPrevProg a[href*=scode]')]
        return items

    def get_live_streaming_url(self, source_url):
        """
        Returns the link to the channel's streaming media
        :param source_url: channel's id
        :return: string
        """
        r = requests.get(config['urls']['live_streaming'].format(source_url))
        if r.status_code == 200:
            soup = BeautifulSoup(r.content, 'html5lib')
            url = soup.html.body.playbacklinks.fileurl.get_text()
            # return url[0:url.find('m3u8') + 4]
            return url
            # http://62.90.90.44/iba_radio-betMRepeat/_definst_/smil:radio-betM.smil/playlist.m3u8
        return ''

    def get_vod_streaming(self, schedule_code):
        """
        Returns the id of the program's streaming media
        :param schedule_code: program schedule's id
        :return: string
        """

        r = requests.get('{0}{1}'.format(config['urls']['website'], config['urls']['program_vod'].format(schedule_code)))
        if r.status_code == 200:
            soup = BeautifulSoup(r.content, 'html5lib')
            media_id = soup.find('div', id='playerUrl').get_text()
            r2 = requests.get(config['urls']['vod_streaming'].format(media_id))
            if r2.status_code == 200:
                r2.encoding = 'UTF-8'
                soup2 = BeautifulSoup(r2.text, 'html5lib')
                return soup2.html.body.metadata if soup2.html.body.metadata else ''
        return ''

    def set_storage(self, name, skey, svalue):
        """
        Stores parameter in storage
        :param name: Storage name
        :param skey: Storage item key
        :param svalue: Storage item value
        :return:
        """
        storage = self.plugin.get_storage(name, TTL=24)
        storage[skey] = svalue

    def get_storage(self, name, skey):
        """
        Returns parameter in storage
        :param name: Storage name
        :param skey: Storage item key
        :return:
        """
        storage = self.plugin.get_storage(name)
        return storage[skey]
