#!/usr/bin/python

import os, sys, urllib, json, re, shutil, glob, platform
import xbmcaddon, xbmcgui, xbmc, time, datetime, urllib2
import json

def upload_file(filepath):
	file_content = open(filepath, 'r').read()
	post_dict = {
		'data': file_content,
		'project': 'www',
		'language': 'text',
		'expire': 1209600,
	}
	post_data = json.dumps(post_dict)
	headers = {
		'User-Agent': '%s-%s' % (AddonName, AddonVersion),
		'Content-Type': 'application/json',
	}
	req = urllib2.Request('http://xbmclogs.com/api/json/create', post_data, headers)
	response = urllib2.urlopen(req).read()
	try:
		response_data = json.loads(response)
	except:
		response_data = None
	if response_data and response_data.get('result', {}).get('id'):
		paste_id = response_data['result']['id']
		print "***** Log Upload {0}".format(paste_id)
		return paste_id
	else:
		print "***** Error Log Upload {0}".format(repr(response))

def main():
	global AddonName,baseUrl,Addon,LOG,AddonVersion
	addonID = "plugin.video.thewiz.wall"
	Addon = xbmcaddon.Addon(addonID)
	AddonName = Addon.getAddonInfo("name")
	AddonPath = Addon.getAddonInfo("path")
	AddonVersion = Addon.getAddonInfo('version')

	logfilep = xbmc.translatePath(os.path.join("special://userdata/addon_data/plugin.video.thewiz.wall/", "thewiz.wall.log")).decode("utf-8")	
	logID = upload_file(logfilep)
	Addon.setSetting("UploadLog","false")
	if logID and len(logID) > 5:
		Addon.setSetting("LastLog",logID)
		dlg = xbmcgui.Dialog()
		dlg.ok('TheWiz Media Wall', 'Log File ID: {0}'.format(logID))
	addonFolder = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
	FileSetting = os.path.join(addonFolder,"settings.xml")
	BackupSetting = os.path.join(addonFolder,"library","settings.xml")
	shutil.copyfile(FileSetting,BackupSetting)

	sys.exit(1)