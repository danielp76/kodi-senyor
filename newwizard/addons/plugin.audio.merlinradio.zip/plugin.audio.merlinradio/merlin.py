import sys
import xbmcgui
import xbmcplugin
import xbmc
import xbmcgui
import xbmcaddon

xbmc.executebuiltin('Container.SetViewMode(500)')

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://mwiz.co.uk/radio/STOP.m3u'
li = xbmcgui.ListItem('[COLOR red][B]S T O P[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/stop.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/stop.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/stopmusic.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio1_mf_p'
li = xbmcgui.ListItem('[COLOR gold][B]ABSOLUTE RADIO[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/absolute.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/absolute.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://aacplus-ac-64.timlradio.co.uk/'
li = xbmcgui.ListItem('[COLOR gold][B]ABSOLUTE CLASSIC ROCK[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/absolute.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/absolute.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://aacplus-a6-64.timlradio.co.uk/'
li = xbmcgui.ListItem('[COLOR gold][B]ABSOLUTE 60s[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/absolute.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/absolute.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://aacplus-a7-64.timlradio.co.uk/'
li = xbmcgui.ListItem('[COLOR gold][B]ABSOLUTE 70s[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/absolute.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/absolute.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://aacplus-a8-64.timlradio.co.uk/'
li = xbmcgui.ListItem('[COLOR gold][B]ABSOLUTE 80s[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/absolute.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/absolute.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://aacplus-a9-64.timlradio.co.uk/'
li = xbmcgui.ListItem('[COLOR gold][B]ABSOLUTE 90s[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/absolute.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/absolute.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://aacplus-a0-64.timlradio.co.uk/'
li = xbmcgui.ListItem('[COLOR gold][B]ABSOLUTE 00s[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/absolute.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/absolute.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio1_mf_p'
li = xbmcgui.ListItem('[COLOR gold][B]BBC RADIO 1[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/bbc.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/bbc.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio1xtra_mf_p'
li = xbmcgui.ListItem('[COLOR gold][B]BBC RADIO 1 EXTRA[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/bbc.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/bbc.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio2_mf_p'
li = xbmcgui.ListItem('[COLOR gold][B]BBC RADIO 2[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/bbc.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/bbc.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio3_mf_p'
li = xbmcgui.ListItem('[COLOR gold][B]BBC RADIO 3[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/bbc.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/bbc.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio4fm_mf_p'
li = xbmcgui.ListItem('[COLOR gold][B]BBC RADIO 4[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/bbc.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/bbc.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio5live_mf_p'
li = xbmcgui.ListItem('[COLOR gold][B]BBC RADIO 5 LIVE[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/bbc.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/bbc.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_radio5extra_mf_p'
li = xbmcgui.ListItem('[COLOR gold][B]BBC RADIO 5 LIVE EXTRA[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/bbc.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/bbc.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_6music_mf_p'
li = xbmcgui.ListItem('[COLOR gold][B]BBC RADIO 6 MUSIC[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/bbc.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/bbc.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_lrleeds_mf_q?s=1463661678&e=1463676078&h=5361af184406463f0684987f828f9492'
li = xbmcgui.ListItem('[COLOR gold][B]BBC RADIO LEEDS[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/bbc.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/bbc.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_lrsheff_mf_q'
li = xbmcgui.ListItem('[COLOR gold][B]BBC RADIO SHEFFIELD[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/bbc.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/bbc.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://bbcmedia.ic.llnwd.net/stream/bbcmedia_lrtees_mf_q?s=1463668823&e=1463683223&h=9aca4ecfc483ae58e345d8139cc1592d'
li = xbmcgui.ListItem('[COLOR gold][B]BBC RADIO TEES[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/bbc.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/bbc.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://icy-e-05-gos.sharp-stream.com:80/tcbridge.mp3'
li = xbmcgui.ListItem('[COLOR gold][B]BRIDGE FM[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/bridge.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/bridge.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://media-the.musicradio.com:80/CapitalYorkshireSouthWest'
li = xbmcgui.ListItem('[COLOR gold][B]CAPITAL YORKSHIRE[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/capital.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/capital.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://icy-e-bl-04-cr.sharp-stream.com:8000/clyde1.aac'
li = xbmcgui.ListItem('[COLOR gold][B]CLYDE 1[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/clyde1.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/clyde1.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://lincs.planetwideradio.com:8010/dearnefmaac'
li = xbmcgui.ListItem('[COLOR gold][B]DEARNE FM[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/dearne.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/dearne.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://media-the.musicradio.com:80/Gold'
li = xbmcgui.ListItem('[COLOR gold][B]GOLD[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/gold.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/gold.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://icy-e-bl-06-cr.sharp-stream.com:8000/hallam.aac'
li = xbmcgui.ListItem('[COLOR gold][B]HALLAM FM[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/hallam.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/hallam.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://media-the.musicradio.com:80/HeartLondonMP3'
li = xbmcgui.ListItem('[COLOR gold][B]HEART[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/heart.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/heart.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://icy-e-bl-03-gos.sharp-stream.com:8000/heat.aac'
li = xbmcgui.ListItem('[COLOR gold][B]HEAT[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/heat.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/heat.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://198.105.220.12:9623/Live'
li = xbmcgui.ListItem('[COLOR gold][B]IBIZA LIVE[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/ibiza.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/ibiza.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://icy-e-bl-05-cr.sharp-stream.com:8000/kerrang.aac'
li = xbmcgui.ListItem('[COLOR gold][B]KERRANG[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/kerrang.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/kerrang.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://icy-e-ba-05-cr.sharp-stream.com:8000/kissnational.mp3'
li = xbmcgui.ListItem('[COLOR gold][B]KISS[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/kiss.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/kiss.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://icy-e-bl-06-cr.sharp-stream.com:8000/kisstory.mp3'
li = xbmcgui.ListItem('[COLOR gold][B]KISSTORY[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/kisstory.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/kisstory.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://icy-e-bz-02-gos.sharp-stream.com:8000/magic1054.aac'
li = xbmcgui.ListItem('[COLOR gold][B]MAGIC[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/magic.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/magic.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://stream2.radiomonitor.com:80/Peak'
li = xbmcgui.ListItem('[COLOR gold][B]PEAK[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/peak.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/peak.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://5.39.82.219:5210'
li = xbmcgui.ListItem('[COLOR gold][B]PLANET ROCK[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/rock.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/rock.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://media-the.musicradio.com:80/RadioXManchesterMP3'
li = xbmcgui.ListItem('[COLOR gold][B]RADIO X MANCS[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/radiox.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/radiox.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://lincs.planetwideradio.com:8025/rotherfmaac'
li = xbmcgui.ListItem('[COLOR gold][B]ROTHER FM[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/rother.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/rother.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://media-the.musicradio.com:80/SmoothLondonMP3'
li = xbmcgui.ListItem('[COLOR gold][B]SMOOTH[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/smooth.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/smooth.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://icy-e-bz-05-cr.sharp-stream.com:8000/tayfm.aac'
li = xbmcgui.ListItem('[COLOR gold][B]TAY FM[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/tay.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/tay.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://icecast.commedia.org.uk:8000/unity.mp3'
li = xbmcgui.ListItem('[COLOR gold][B]UNITY FM[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/unity.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/unity.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://icy-e-bz-01-gos.sharp-stream.com:8000/viking.aac'
li = xbmcgui.ListItem('[COLOR gold][B]VIKING FM[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/viking.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/viking.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://str1.sad.ukrd.com:80/yorkshirecoastb'
li = xbmcgui.ListItem('[COLOR gold][B]YORKSHIRE COAST[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/yorkcoast.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/yorkcoast.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

addon_handle = int(sys.argv[1])
xbmcplugin.setContent(addon_handle, 'audio')
url = 'http://stream1.myradioapps.com:80/radio_yorkshire'
li = xbmcgui.ListItem('[COLOR gold][B]YORKSHIRE RADIO[/B][/COLOR]', iconImage='special://home/addons/plugin.audio.merlinradio/resources/yorkradio.png', thumbnailImage= 'special://home/addons/plugin.audio.merlinradio/resources/yorkradio.png')
li.setProperty('fanart_image', 'special://home/addons/plugin.audio.merlinradio/resources/fanart.jpg')
xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li)

xbmcplugin.endOfDirectory(addon_handle)