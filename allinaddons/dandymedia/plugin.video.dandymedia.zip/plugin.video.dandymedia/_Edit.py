import xbmcaddon

MainBase = 'https://raw.githubusercontent.com/dandy0850/iStream/master/test/home.txt'
addon = xbmcaddon.Addon('plugin.video.dandymedia')