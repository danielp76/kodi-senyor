# -*- coding: utf-8 -*-
#------------------------------------------------------------
# iConspire special thanks to original authors of the code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# Author: Dandymedia
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.iconspire'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "UCyX8H5paMpxF9u9tAXW7vTQ"
YOUTUBE_CHANNEL_ID_2 = "UC9cCqWHsMabi0y1UD2M6CVg"
YOUTUBE_CHANNEL_ID_3 = "UCYDhcbkYrCIkWHzFi4HEh7Q"
YOUTUBE_CHANNEL_ID_4 = "UCbHnk8NjjHRtj-manaXbCnA"
YOUTUBE_CHANNEL_ID_5 = "UCod1WI0tgnXwsiyZUMwLQzw"
YOUTUBE_CHANNEL_ID_6 = "UC_KK9eFLoAIlGKs2yyz6QCg"
YOUTUBE_CHANNEL_ID_7 = "UCPZiqlNI3RLyF47QTdq93GQ"
YOUTUBE_CHANNEL_ID_8 = "UCaasFoY9yYQpOfL00N3nSxg"
YOUTUBE_CHANNEL_ID_9 = "UC2lkQ3qo9nopVxGRZnND21Q"
YOUTUBE_CHANNEL_ID_10 = "UCLpf2P6JvAl3SU6LLHPa8-Q"
YOUTUBE_CHANNEL_ID_11 = "UCzKNZFJ3S5ibmryMeSrxWmQ"
YOUTUBE_CHANNEL_ID_12 = "UCPTOZT-H-ZXmTV4TYnKL9tA"
YOUTUBE_CHANNEL_ID_13 = "UCEOpk5s7Yd3RQXkaqv8PwDw"
YOUTUBE_CHANNEL_ID_14 = "UCqIYcGfsDIFZoe6AIcKZY9w"
YOUTUBE_CHANNEL_ID_15 = "UCrrOic-og4HzhleZqOq4L-A"

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="Xendrius",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://yt3.ggpht.com/-07MTDNZHByw/AAAAAAAAAAI/AAAAAAAAAAA/9gjskXvjWuM/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Top Conspiracy Documentaries",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://yt3.ggpht.com/-pOXP0CnNfts/AAAAAAAAAAI/AAAAAAAAAAA/mZSyhdOZiPA/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Conspiracy Zone",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://yt3.ggpht.com/-IBehxh_7WOQ/AAAAAAAAAAI/AAAAAAAAAAA/h7g8KE03DXE/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Conspiracy News Documentary",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://yt3.ggpht.com/-GJud3P6RxY8/AAAAAAAAAAI/AAAAAAAAAAA/gyMkXXUYCTM/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="We are Anonymous",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://yt3.ggpht.com/-l6Kp6wecCp8/AAAAAAAAAAI/AAAAAAAAAAA/D7XLPLfzlAY/s500-c-k-no/photo.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="World Documentary Channel",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://yt3.ggpht.com/-fAHqi2UmgLE/AAAAAAAAAAI/AAAAAAAAAAA/QSvANGunQgA/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Alltime Conspiracies",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://yt3.ggpht.com/-qFfLwq5wqQY/AAAAAAAAAAI/AAAAAAAAAAA/0vKr8Y4Dfyo/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="UFOTV The Disclosure Network",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://yt3.ggpht.com/-LzxbTMc5jx8/AAAAAAAAAAI/AAAAAAAAAAA/oJYbn_2y4ec/s500-c-k-no/photo.jpg",
        folder=True )
        
    plugintools.add_item( 
        #action="", 
        title="AIO Documentaries",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://yt3.ggpht.com/-6hAdcTxpTU4/AAAAAAAAAAI/AAAAAAAAAAA/0GvgMdZzzUk/s500-c-k-no/photo.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Documentary TV",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://yt3.ggpht.com/-rK2fbGgiDzI/AAAAAAAAAAI/AAAAAAAAAAA/UUPR_jAmQnI/s500-c-k-no/photo.jpg",
        folder=True )                

    plugintools.add_item( 
        #action="", 
        title="Alien Documentary TV",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://yt3.ggpht.com/-FlaE2WCJKNY/AAAAAAAAAAI/AAAAAAAAAAA/1U2fMioobWU/s500-c-k-no/photo.jpg",
        folder=True )    

    plugintools.add_item( 
        #action="", 
        title="Prime Documentary",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://yt3.ggpht.com/-KgvvdpGK7Mk/AAAAAAAAAAI/AAAAAAAAAAA/lWSEc_ESYZ0/s500-c-k-no/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="Just Documentary",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://yt3.ggpht.com/-YBQ4BmPw1Zs/AAAAAAAAAAI/AAAAAAAAAAA/WxaflkuLNa0/s500-c-k-no/photo.jpg",
        folder=True )  

    plugintools.add_item( 
        #action="", 
        title="Documentary Films",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://yt3.ggpht.com/-L4qtj01rqEI/AAAAAAAAAAI/AAAAAAAAAAA/PNtLd1Y3cXA/s500-c-k-no/photo.jpg",
        folder=True ) 
		
    plugintools.add_item( 
        #action="", 
        title="Stuff They Don't Want You To Know",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://yt3.ggpht.com/-b_dYhC2SG5I/AAAAAAAAAAI/AAAAAAAAAAA/nf_GmfPp7r8/s500-c-k-no/photo.jpg",
        folder=True )
run()
