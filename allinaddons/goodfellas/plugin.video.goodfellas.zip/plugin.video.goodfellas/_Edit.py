import xbmcaddon

MainBase = 'https://goo.gl/jMMZoW'
addon = xbmcaddon.Addon('plugin.video.goodfellas')